using Microsoft.AspNetCore.Authentication.Certificate;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Claims;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;

namespace MiddleWareTest
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;

        }

        public IConfiguration Configuration { get; }


        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            Log.Information("ConfigureServices - Adding Controllers ");
            services.AddSingleton<MyCertificateValidationService>();

            //services.AddCertificateForwarding(options =>
            //{
            //    options.CertificateHeader = "X-ARR-ClientCert";
            //    options.HeaderConverter = (headerValue) =>
            //    {
            //        X509Certificate2 clientCertificate = null;
            //        if (!string.IsNullOrWhiteSpace(headerValue))
            //        {
            //            byte[] bytes = StringToByteArray(headerValue);
            //            clientCertificate = new X509Certificate2(bytes);
            //        }

            //        return clientCertificate;
            //    };
            //});

            Log.Information("ConfigureServices - AddAuthentication");
            services.AddAuthentication(CertificateAuthenticationDefaults.AuthenticationScheme)
                .AddCertificate(options => // code from ASP.NET Core sample
        {
            options.AllowedCertificateTypes = CertificateTypes.All;
            options.Events = new CertificateAuthenticationEvents
            {
                OnCertificateValidated = context =>
                {
                    Log.Information("OnCertificateValidated - Called");
                    var validationService =
                        context.HttpContext.RequestServices.GetService<MyCertificateValidationService>();

                    Log.Information("validationService.ValidateCertificate - Calling");
                    if (validationService.ValidateCertificate(context.ClientCertificate))
                    {
                        Log.Information("Creating new Claim");
                        var claims = new[]
                        {
                            new Claim(ClaimTypes.NameIdentifier, context.ClientCertificate.Subject, ClaimValueTypes.String, context.Options.ClaimsIssuer),
                            new Claim(ClaimTypes.Name, context.ClientCertificate.Subject, ClaimValueTypes.String, context.Options.ClaimsIssuer)
                        };

                        Log.Information("Creating new ClaimPrincipal");
                        context.Principal = new ClaimsPrincipal(new ClaimsIdentity(claims, context.Scheme.Name));
                        Log.Information("Marking the Success");
                        context.Success();
                    }
                    else
                    {
                        context.Fail("invalid cert");
                    }

                    return Task.CompletedTask;
                }
            };
        });

            services.AddAuthorization();

            services.AddControllers();
            services.AddSwaggerGen(swagger =>
            {
                swagger.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "Demo Employee API",
                    Version = "v1.1",
                    Description = "API to unerstand request and response schema.",
                });
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            //app.UseCertificateForwarding();
            app.UseAuthentication();
            app.UseAuthorization();

            app.Use(async (context, next) =>
            {
                // Do work that doesn't write to the Response.
                Log.Information("Reteriving Client Certificate.");
                var clientCert = await context.Request.HttpContext.Connection.GetClientCertificateAsync();
                if (clientCert == null)
                {
                    Log.Information("clientCert == null - in middleware");
                }
                else
                {
                    Log.Information("clientCert found - in middleware");
                }
                
                await next.Invoke();
                // Do logging or other work that doesn't write to the Response.
            });


            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Demo Employee API");
            });
        }

        public class VerifyClientCertificate : IAuthorizationRequirement
        {

            public VerifyClientCertificate(bool VerifyClientCertificate)
            {
                this.ValidateClientCertificate = VerifyClientCertificate;
            }

            public bool ValidateClientCertificate { get; private set; }
        }

        public class VerifyClientCertificateHandler :
             AuthorizationHandler<VerifyClientCertificate>
        {
            protected override Task HandleRequirementAsync(
              AuthorizationHandlerContext context,
              VerifyClientCertificate requirement)
            {
                context.User.Identities.FirstOrDefault().AddClaim(new Claim("VerifyCertificate", "True"));
                context.Succeed(requirement);
                return Task.CompletedTask;
            }

        }

        public class MyCertificateValidationService
        {

            public bool ValidateCertificate(X509Certificate2 clientCertificate)
            {
                if (clientCertificate == null)
                    Log.Information("Client Server Not Found");
                else
                    Log.Information("Client Server Found - Subject:" + clientCertificate.Subject);


                return true;
            }
        }


    }
}
